/* Jay Infoservices — main.js */

(function () {
  'use strict';

  // --- ELEMENTS ---
  var header       = document.getElementById('siteHeader');
  var progressFill = document.getElementById('progressFill');
  var navToggle    = document.getElementById('navToggle');
  var navLinks     = document.getElementById('navLinks');
  var navLinkItems = document.querySelectorAll('.nav-link');
  var menuLinks    = document.querySelectorAll('#navLinks a');
  var yearEl       = document.getElementById('year');

  // --- YEAR ---
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // --- STATE ---
  var lastScrollY = 0;
  var menuOpen    = false;
  var SCROLL_THRESHOLD = 40;
  var MOBILE_BP        = 860;

  // --- SCROLL HANDLER ---
  function onScroll() {
    var scrollY = window.scrollY;
    var docH    = document.documentElement.scrollHeight - window.innerHeight;

    if (progressFill) {
      progressFill.style.width = docH > 0 ? (scrollY / docH * 100) + '%' : '0%';
    }

    if (header) {
      if (scrollY > SCROLL_THRESHOLD) {
        header.classList.add('is-scrolled');
      } else {
        header.classList.remove('is-scrolled');
      }

      // Hide/show nav on scroll direction (mobile only, not when menu open)
      if (window.innerWidth <= MOBILE_BP && !menuOpen) {
        if (scrollY > lastScrollY && scrollY > 100) {
          header.classList.add('is-hidden');
        } else {
          header.classList.remove('is-hidden');
        }
      }
    }

    lastScrollY = scrollY;
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // --- HAMBURGER ---
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      menuOpen = !menuOpen;
      navLinks.classList.toggle('is-open', menuOpen);
      navToggle.setAttribute('aria-expanded', menuOpen ? 'true' : 'false');
      if (header) header.classList.remove('is-hidden');
    });

    // Close menu when a link is clicked
    menuLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        menuOpen = false;
        navLinks.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // --- SCROLLSPY ---
  var sections = document.querySelectorAll('.section[id], .hero[id]');
  if ('IntersectionObserver' in window && sections.length && navLinkItems.length) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          navLinkItems.forEach(function (link) {
            link.classList.toggle('is-active', link.hash === '#' + entry.target.id);
          });
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });

    sections.forEach(function (section) { observer.observe(section); });
  }

  // --- CONTACT FORM ---
  var form = document.getElementById('contactForm');
  if (form) {
    var loadedAt   = Date.now();
    var elapsedEl  = document.getElementById('jayElapsed');
    var submitBtn  = form.querySelector('button[type="submit"]');
    var btnLabel   = submitBtn ? submitBtn.textContent : '';

    form.addEventListener('submit', function () {
      if (elapsedEl) elapsedEl.value = String(Date.now() - loadedAt);
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Sending…';
      }
    });

    // Re-enable the button if the visitor comes back with the browser's back button.
    window.addEventListener('pageshow', function () {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = btnLabel;
      }
    });

    // Show the result message after the redirect (?contact=sent etc.).
    var params = new URLSearchParams(window.location.search);
    var status = params.get('contact');
    if (status) {
      var notice = document.querySelector('.form-notice[data-status="' + status + '"]');
      if (notice) {
        notice.hidden = false;
      }
      params.delete('contact');
      var query = params.toString();
      if (window.history && window.history.replaceState) {
        window.history.replaceState(null, '', window.location.pathname + (query ? '?' + query : '') + window.location.hash);
      }
    }
  }
})();
