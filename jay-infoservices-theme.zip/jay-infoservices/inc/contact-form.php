<?php
/**
 * Contact form: shortcode, spam protection, handler and Customizer settings.
 *
 * @package jay-infoservices
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Where enquiries are sent. Customizer value, else the WordPress admin email.
 */
function jay_contact_recipient() {
	$email = sanitize_email( (string) get_theme_mod( 'jay_contact_email', '' ) );
	if ( $email && is_email( $email ) ) {
		return $email;
	}
	return get_option( 'admin_email' );
}

/**
 * Best-effort visitor IP, used only for rate limiting.
 */
function jay_client_ip() {
	$keys = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );
	foreach ( $keys as $key ) {
		if ( ! empty( $_SERVER[ $key ] ) ) {
			$parts = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) );
			$ip    = trim( $parts[0] );
			if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				return $ip;
			}
		}
	}
	return '0.0.0.0';
}

/**
 * [jay_contact_form] shortcode.
 */
function jay_contact_form_shortcode() {
	$site_key = trim( (string) get_theme_mod( 'jay_turnstile_site_key', '' ) );
	if ( '' !== $site_key ) {
		wp_enqueue_script( 'jay-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', array(), null, true ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
	}

	ob_start();
	?>
	<div class="contact-form-wrap">
		<div class="form-notice form-notice--ok" data-status="sent" role="status" hidden>Thank you. Your message has been sent and we will reply soon.</div>
		<div class="form-notice form-notice--error" data-status="invalid" role="alert" hidden>Please check your name, email, subject and message, then try again.</div>
		<div class="form-notice form-notice--error" data-status="captcha" role="alert" hidden>Please complete the security check and try again.</div>
		<div class="form-notice form-notice--error" data-status="spam" role="alert" hidden>Your message was blocked as spam. Remove extra links and try again.</div>
		<div class="form-notice form-notice--error" data-status="limit" role="alert" hidden>Too many messages were sent from your connection. Please try again later.</div>
		<div class="form-notice form-notice--error" data-status="error" role="alert" hidden>Your message could not be sent. Please wait a moment and try again.</div>

		<form class="contact-form" id="contactForm" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="jay_contact">
			<input type="hidden" name="jay_elapsed" id="jayElapsed" value="0">

			<div class="form-grid">
				<div class="form-field">
					<label for="jay-name">Name</label>
					<input type="text" id="jay-name" name="jay_name" required maxlength="100" autocomplete="name">
				</div>
				<div class="form-field">
					<label for="jay-email">Email</label>
					<input type="email" id="jay-email" name="jay_email" required maxlength="150" autocomplete="email">
				</div>
			</div>

			<div class="form-field">
				<label for="jay-subject">Subject</label>
				<input type="text" id="jay-subject" name="jay_subject" required maxlength="150">
			</div>

			<div class="form-field">
				<label for="jay-message">Message</label>
				<textarea id="jay-message" name="jay_message" rows="6" required maxlength="5000"></textarea>
			</div>

			<div class="hp-field" aria-hidden="true">
				<label for="jay-website">Leave this field empty</label>
				<input type="text" id="jay-website" name="jay_website" tabindex="-1" autocomplete="off">
			</div>

			<?php if ( '' !== $site_key ) : ?>
				<div class="cf-turnstile" data-sitekey="<?php echo esc_attr( $site_key ); ?>"></div>
			<?php endif; ?>

			<button type="submit" class="btn btn--gold">Send message</button>
			<noscript><p class="form-note">Please turn on JavaScript to send a message with this form.</p></noscript>
		</form>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'jay_contact_form', 'jay_contact_form_shortcode' );

/**
 * Load the Turnstile script asynchronously.
 *
 * @param string $tag    Script tag.
 * @param string $handle Script handle.
 * @return string
 */
function jay_script_attrs( $tag, $handle ) {
	if ( 'jay-turnstile' === $handle ) {
		return str_replace( ' src=', ' async defer src=', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'jay_script_attrs', 10, 2 );

/**
 * Handle the form submission.
 */
function jay_handle_contact() {
	$redirect = wp_get_referer();
	$redirect = $redirect ? strtok( $redirect, '#' ) : home_url( '/' );
	$redirect = remove_query_arg( 'contact', $redirect );

	$finish = function ( $status ) use ( $redirect ) {
		wp_safe_redirect( add_query_arg( 'contact', $status, $redirect ) . '#contact' );
		exit;
	};

	// 1. Honeypot: bots fill the hidden field. Pretend it worked.
	$honeypot = isset( $_POST['jay_website'] ) ? trim( (string) wp_unslash( $_POST['jay_website'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	if ( '' !== $honeypot ) {
		$finish( 'sent' );
	}

	// 2. Time trap: the page script reports how long the form was open.
	$elapsed = isset( $_POST['jay_elapsed'] ) ? absint( $_POST['jay_elapsed'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	if ( $elapsed < 2000 ) {
		$finish( 'error' );
	}

	// 3. Rate limit per visitor and overall.
	$ip_key    = 'jay_cf_' . md5( jay_client_ip() );
	$ip_count  = (int) get_transient( $ip_key );
	$all_count = (int) get_transient( 'jay_cf_all' );
	if ( $ip_count >= 5 || $all_count >= 40 ) {
		$finish( 'limit' );
	}
	set_transient( $ip_key, $ip_count + 1, HOUR_IN_SECONDS );
	set_transient( 'jay_cf_all', $all_count + 1, HOUR_IN_SECONDS );

	// 4. Optional Cloudflare Turnstile check.
	$secret = trim( (string) get_theme_mod( 'jay_turnstile_secret_key', '' ) );
	if ( '' !== $secret ) {
		$token = isset( $_POST['cf-turnstile-response'] ) ? sanitize_text_field( wp_unslash( $_POST['cf-turnstile-response'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( '' === $token ) {
			$finish( 'captcha' );
		}
		$response = wp_remote_post(
			'https://challenges.cloudflare.com/turnstile/v0/siteverify',
			array(
				'timeout' => 10,
				'body'    => array(
					'secret'   => $secret,
					'response' => $token,
					'remoteip' => jay_client_ip(),
				),
			)
		);
		$result   = is_wp_error( $response ) ? array() : json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $result['success'] ) ) {
			$finish( 'captcha' );
		}
	}

	// 5. Validate and sanitise the fields.
	$name    = isset( $_POST['jay_name'] ) ? sanitize_text_field( wp_unslash( $_POST['jay_name'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	$email   = isset( $_POST['jay_email'] ) ? sanitize_email( wp_unslash( $_POST['jay_email'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	$subject = isset( $_POST['jay_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['jay_subject'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	$message = isset( $_POST['jay_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['jay_message'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

	if ( '' === $name || '' === $subject || ! is_email( $email ) || strlen( $message ) < 5 || strlen( $message ) > 5000 ) {
		$finish( 'invalid' );
	}

	// 6. Too many links is a strong spam signal.
	if ( preg_match_all( '#https?://|www\.#i', $message ) > 2 ) {
		$finish( 'spam' );
	}

	// 7. Send.
	$body  = 'Name: ' . $name . "\n";
	$body .= 'Email: ' . $email . "\n";
	$body .= 'Subject: ' . $subject . "\n\n";
	$body .= "Message:\n" . $message . "\n\n";
	$body .= '-- ' . "\n" . 'Sent from the contact form at ' . home_url( '/' );

	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		'Reply-To: ' . $email,
	);

	$sent = wp_mail( jay_contact_recipient(), '[Website] ' . $subject, $body, $headers );

	$finish( $sent ? 'sent' : 'error' );
}
add_action( 'admin_post_nopriv_jay_contact', 'jay_handle_contact' );
add_action( 'admin_post_jay_contact', 'jay_handle_contact' );

/**
 * Customizer settings: recipient email and optional Turnstile keys.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function jay_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'jay_contact',
		array(
			'title'    => 'Contact form',
			'priority' => 160,
		)
	);

	$wp_customize->add_setting(
		'jay_contact_email',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_email',
		)
	);
	$wp_customize->add_control(
		'jay_contact_email',
		array(
			'label'       => 'Send enquiries to',
			'description' => 'Leave empty to use the WordPress admin email.',
			'section'     => 'jay_contact',
			'type'        => 'email',
		)
	);

	$wp_customize->add_setting(
		'jay_turnstile_site_key',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'jay_turnstile_site_key',
		array(
			'label'       => 'Cloudflare Turnstile site key (optional)',
			'description' => 'Free extra spam protection. Needs both keys.',
			'section'     => 'jay_contact',
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'jay_turnstile_secret_key',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'jay_turnstile_secret_key',
		array(
			'label'   => 'Cloudflare Turnstile secret key (optional)',
			'section' => 'jay_contact',
			'type'    => 'text',
		)
	);
}
add_action( 'customize_register', 'jay_customize_register' );
